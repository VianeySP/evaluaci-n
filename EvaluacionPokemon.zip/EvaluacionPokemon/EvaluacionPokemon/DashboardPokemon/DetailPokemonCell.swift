//
//  DetailPokemonCell.swift
//  EvaluacionPokemon
//
//  Created by Sandra Sanchez on 07/07/21.
//

import Foundation
import UIKit

class DetailPokemonCell: UITableViewCell {
    
}
