protocol InteractorInterface: class {
}

extension InteractorInterface {
}
